import smtplib
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from tkinter import ttk, messagebox
import tkinter as tk
import re
import os
import secrets
import string
from Account import BankAccount

headerFont = ('Helvetica', 12, "bold")
dodyFont = ('Helvetica', 12, "normal")

accounts = "BankAccountData.txt"
transaction_log = "transaction_log.txt"


def load_account_info():
    users = {}
    if os.path.exists(accounts):
        with open(accounts, "r") as file:
            for line in file:
                username, password, name, surname, gender, email, contact, acc_num, balance = line.strip().split(",")
                users[username] = {"username": username, "password": password, "name": name, "surname": surname, "gender": gender, "email": email, "contact": contact, "account_num": acc_num, "balance": balance}
    return users

def validate_entry_isalpha(char):

    if char.isalpha() or char == "":
        return True
    else:
        return False


class BankingAppGUI:


    def __init__(self, root):
        self.root = root
        self.root.title("main")

        self.root.protocol("WM_DELETE_WINDOW", self.close_application)
        self.account = None
        self.users = load_account_info()
        self.main()

        self.alpha_validation = root.register(validate_entry_isalpha)


    def main(self):
        self.page_GUI()

    def page_GUI(self):  # Parent window one

        self.option_menu = tk.Toplevel(self.root)
        self.option_menu.title("Login Options")
        self.root.withdraw()

        ttk.Label(self.option_menu, text='Young Division Bank', padding=20).grid(row=0, column=0)
        ttk.Button(self.option_menu, text='Login', command=self.login_GUI).grid(row=1, column=0)
        ttk.Button(self.option_menu, text='Sign Up', command=self.sign_up_GUI).grid(row=2, column=0)

    def sign_up_GUI(self):  # Child window Signup
        self.signup_window = tk.Toplevel(self.option_menu)
        self.signup_window.title("Sign Up Window")
        self.option_menu.withdraw()

        self.x = self.root.winfo_x()
        self.y = self.root.winfo_y()

        self.signup_window.geometry("+%d+%d" % (self.x + 0, self.y + 0))

        def on_child_window_close():
            self.option_menu.deiconify()
            self.signup_window.destroy()

        self.signup_window.protocol("WM_DELETE_WINDOW", on_child_window_close)

        def generate_password():
            letters = string.ascii_letters
            digits = string.digits
            special_chars = string.punctuation
            selection_list = letters + digits + special_chars
            password_len = 10
            password = ''

            for i in range(password_len):
                password += ''.join(secrets.choice(selection_list))

            self.gpassword_entry.config(state='normal')
            self.gpassword_entry.delete(0, tk.END)
            self.gpassword_entry.insert(0, str(password))
            self.gpassword_entry.config(state='readonly')
            print(self.selected_value.get())
            self.btn_register["state"] = "enable"
            self.btn_passsword["state"] = "disable"

        def clear_all():

            first_name_var.set("")
            last_name_var.set("")
            email_var.set("")
            contact_var.set("")
            username_var.set("")
            gpassword_var.set("")

            self.first_name_entry.focus_set()
            self.gpassword_entry.config(state='normal')
            self.gpassword_entry.delete(0, tk.END)
            self.gpassword_entry.config(state='readonly')
            self.btn_passsword["state"] = "enable"
            self.btn_register["state"] = "disabled"
            self.btn_passsword["state"] = "enable"
            self.btn_register["state"] = "disabled"

        def call():
            response = messagebox.askquestion('Login',
                                              'Already have an account?')

            if response == 'yes':
                self.login_GUI()
                self.signup_window.withdraw()

            else:
                messagebox.showinfo('Cancelled', 'Please sign up to get access to the banking app.')

        def contact_length(length):
            if len(length) > 10:
                return False
            return True

        contact_len = (root.register(contact_length), '%P')
        #def verification():

        first_name_var = tk.StringVar()
        last_name_var = tk.StringVar()
        email_var = tk.StringVar()
        radio = tk.StringVar()
        contact_var = tk.StringVar()
        username_var = tk.StringVar()
        gpassword_var = tk.StringVar()

        ttk.Label(self.signup_window, text='Sign Up', anchor="w", font=("Arial", 15, "bold")).grid(row=0, column=0)
        ttk.Label(self.signup_window, text='Personal Details').grid(row=1, column=0)
        ttk.Label(self.signup_window, text='First Name:').grid(row=2, column=0)
        self.first_name_entry = ttk.Entry(self.signup_window, textvariable=first_name_var, validate="key",
                                          validatecommand="vcmd")
        self.first_name_entry.grid(row=2, column=1)

        ttk.Label(self.signup_window, text='Last Name:').grid(row=3, column=0)
        self.last_name_entry = ttk.Entry(self.signup_window, textvariable=last_name_var, validate="key",
                                         validatecommand="vcmd")
        self.last_name_entry.grid(row=3, column=1)
        self.selected_value = tk.StringVar()
        self.selected_value.set("Male")
        ttk.Label(self.signup_window, text='Gender: ').grid(row=4, column=0)
        ttk.Radiobutton(self.signup_window, text='Male', variable=self.selected_value, value='Male').grid(row=5,
                                                                                                          column=0)
        ttk.Radiobutton(self.signup_window, text='Female', variable=self.selected_value, value='Female').grid(row=5,
                                                                                                              column=1)

        ttk.Label(self.signup_window, text='Contact:').grid(row=6, column=0)
        self.contact_entry = ttk.Entry(self.signup_window, textvariable=contact_var, validatecommand=contact_len)
        self.contact_entry.grid(row=6, column=1)

        ttk.Label(self.signup_window, text='Email:').grid(row=7, column=0)
        self.email_entry = ttk.Entry(self.signup_window, textvariable=email_var)
        self.email_entry.grid(row=7, column=1)

        ttk.Label(self.signup_window, text='Login Details', font=("Arial", 15, "bold")).grid(row=8, column=0)

        ttk.Label(self.signup_window, text='Username:').grid(row=9, column=0)
        self.username_entry = ttk.Entry(self.signup_window, textvariable=username_var, validate="key",
                                        validatecommand="vcmd")
        self.username_entry.grid(row=9, column=1)

        ttk.Label(self.signup_window, text='Generate Password:').grid(row=10, column=0)
        self.gpassword_entry = ttk.Entry(self.signup_window, textvariable=gpassword_var, state='readonly')
        self.gpassword_entry.grid(row=10, column=1)
        self.btn_passsword = ttk.Button(self.signup_window, text='Generate Password', command=generate_password)
        self.btn_passsword.grid(row=11, column=1)

        self.btn_register = ttk.Button(self.signup_window, text='Register', width=20, command=self.signup)
        self.btn_register["state"] = "disabled"
        self.btn_register.grid(row=12, column=0)
        self.btn_clear = ttk.Button(self.signup_window, text='Clear', width=20, command=clear_all)
        self.btn_clear.grid(row=12, column=1)

        ttk.Label(self.signup_window, text='Already have an account?', padding=10).grid(row=13, column=0)
        self.sign_up_link = tk.Label(self.signup_window, text="Login", foreground="blue", cursor="hand2")
        self.sign_up_link.bind("<Button-1>", lambda e: call())
        self.sign_up_link.grid(row=13, column=1)

    def login_GUI(self):

        def call():
            response = messagebox.askquestion('Sign Up',
                                              'Do you want to create an account?')
            if response == 'yes':
                self.sign_up_GUI()
                self.login_window.withdraw()
            else:
                messagebox.showinfo('Cancelled', 'Please enter your log ins.')

        def forgot_password():
            response = messagebox.askquestion('Forgotten Password',
                                              'Do you wish to resend your password')

            if response == 'yes':
                self.forgot_password_GUI()
                #messagebox.showinfo("Forgotten Password", "Your password has been successfully been sent")
            else:
                messagebox.showinfo('Forgotten Password', 'PLease keep password safe')

        self.login_window = tk.Toplevel(self.option_menu)
        self.login_window.title("Login Window")
        self.option_menu.withdraw()

        self.x = self.root.winfo_x()
        self.y = self.root.winfo_y()
        self.login_window.geometry("+%d+%d" % (self.x + 0, self.y + 0))

        def on_child_window_close():
            self.option_menu.deiconify()
            self.login_window.destroy()

        self.login_window.protocol("WM_DELETE_WINDOW", on_child_window_close)

        ttk.Label(self.login_window, text='Login', font=("Arial", 15, "bold")).grid(row=0, column=0)
        tk.Label(self.login_window, text='Username:', anchor=tk.W).grid(row=1, column=0)
        self.username_login = ttk.Entry(self.login_window, width=30, validate="key", validatecommand=(self.alpha_validation, '%P'))
        self.username_login.grid(row=1, column=1)

        ttk.Label(self.login_window, text='Password:').grid(row=2, column=0)
        self.password_login = ttk.Entry(self.login_window, width=30, show='*')
        self.password_login.grid(row=2, column=1)

        sign_up_link = tk.Label(self.login_window, font=("Arial", 10, "normal"), text="Forgot Password?",
                                foreground="blue",
                                cursor="hand2", pady=10)  # Not complete12347899
        sign_up_link.bind("<Button-1>", lambda e: forgot_password())
        sign_up_link.grid(row=3, column=1)

        ttk.Button(self.login_window, text='Login', command=self.login).grid(row=4, column=0, columnspan=2)

        ttk.Label(self.login_window, text='Dont have an account?', padding=10).grid(row=6, column=0)
        self.sign_up_link = tk.Label(self.login_window, text="Sign Up", foreground="blue", cursor="hand2")
        self.sign_up_link.bind("<Button-1>", lambda e: call())
        self.sign_up_link.grid(row=6, column=1)

    def forgot_password_GUI(self):
        self.forgot_password_window = tk.Toplevel(self.login_window)  # Create a child window
        self.forgot_password_window.title("Forgot Password")
        self.login_window.withdraw()

        def on_child_window_close():
            self.login_window.deiconify()  # Show the parent window again
            self.forgot_password_window.destroy()

        tk.Label(self.forgot_password_window, text="Enter Username:", font=("Arial", 10, "bold")).grid(row=0, column=0)
        self.username_email_address = tk.Entry(self.forgot_password_window)
        self.username_email_address.grid(columnspan=2, row=1, column=0)
        tk.Label(self.forgot_password_window, text="Enter email address:", font=("Arial", 10, "bold")).grid(row=2, column=0)
        self.email_address = tk.Entry(self.forgot_password_window)
        self.email_address.grid(columnspan=2, row=3, column=0)

        tk.Button(self.forgot_password_window, text="Submit", command=self.send_confirmation_email).grid(row=4, column=0)
        tk.Button(self.forgot_password_window, text="Back", command=on_child_window_close).grid(row=4, column=1)

    def send_confirmation_email(self):
        username = self.username_email_address.get()
        mail = self.email_address.get()

        if username in self.users:
            if self.users[username]['email'] == mail:
                self.send_email(username)
            else:
                messagebox.showerror("Error", "Incorrect email. Please try again.")
        else:
            messagebox.showerror("Error", "Username does not exist. Please try again or sign up.")



    def dashboard_GUI(self, username):

        self.dashboard_window = tk.Toplevel(self.root)
        self.dashboard_window.title("Dashboard")
        self.login_window.withdraw()
        self.dashboard_window.geometry('300x450')
        account_info = self.users[username]

        balance = float(self.account.get_balance())

        def call():
            response = messagebox.askquestion('Sign Out',
                                              'Do you really want to sign out?')

            if response == 'yes':
                self.page_GUI()
                self.dashboard_window.withdraw()
            else:
                messagebox.showinfo('Cancelled', 'Sign out unsuccessfully')

        tk.Label(self.dashboard_window, text="Young Division Bank", pady=10, font=("Arial", 15, "bold")).pack()
        tk.Label(self.dashboard_window, text=f"Welcome Back, {account_info['name']} {account_info['surname']}",
                 font=("Arial", 10, "normal"), justify=tk.LEFT).pack()

        self.frmBalance = tk.Frame(self.dashboard_window)
        self.frmBalance.pack(expand=True, fill='both')

        self.balance = ttk.Label(self.dashboard_window, text="Your Balance", font=("Arial", 10, "bold"))
        self.balance.place(x=40, y=85)
        self.amount = ttk.Label(self.dashboard_window, text=f"R{balance:.2f}", font=("Arial", 10, "normal"))
        self.amount.place(x=130, y=115)

        self.lblFrame_trans = tk.LabelFrame(self.dashboard_window, text="Transaction", bd=4, font=("Helvetica 10 bold"))
        self.lblFrame_trans.pack(expand='yes', fill='both')

        ttk.Button(self.lblFrame_trans, text="Deposit", command=self.deposit_GUI).place(x=30, y=10)
        ttk.Button(self.lblFrame_trans, text='Withdrawal', command=self.withdrawal_GUI).place(x=200, y=10)
        ttk.Button(self.lblFrame_trans, text="Transfer", command=self.transfer_GUI).place(x=120, y=10)

        self.lblFrame_fav = tk.LabelFrame(self.dashboard_window, text="Favourite", font=("Helvetica 10 bold"), bd=4)
        self.lblFrame_fav.pack(expand='yes', fill='both')

        ttk.Button(self.lblFrame_fav, text="View Profile", command=self.profile_GUI(username)).place(x=20, y=10)
        ttk.Button(self.lblFrame_fav, text="Airtime", command=self.airtime_GUI).place(x=120, y=10)
        ttk.Button(self.lblFrame_fav, text='Electricity', command=self.electricity_GUI).place(x=200, y=10)

        self.lblFrame_statement = tk.LabelFrame(self.dashboard_window, text="Bank Statement",
                                                font=("Helvetica 10 bold"), bd=4,
                                                height=10)
        self.lblFrame_statement.pack(expand='yes', fill='both')

        ttk.Button(self.lblFrame_statement, text="View Statement", command=self.transaction_GUI).place(x=30, y=15)
        ttk.Button(self.lblFrame_statement, text='Email Statement').place(x=160, y=15)

        self.sign_out = tk.Label(self.dashboard_window, text="Sign Out", padx=7, foreground="blue", cursor="hand2",
                                 font=("Arial", 10, "normal"))
        self.sign_out.bind("<Button-1>", lambda e: call())
        self.sign_out.pack()  # (x=120, y=390)
        tk.Label(self.dashboard_window, text="@Young Division Bank", font=("Arial", 10, "normal"), pady=5).pack()

    def deposit_GUI(self):
        self.deposit_window = tk.Toplevel(self.dashboard_window)  # Create a child window
        self.deposit_window.title("Deposit Window")
        self.dashboard_window.withdraw()

        def on_child_window_close():
            self.dashboard_window.deiconify()  # Show the parent window again
            self.deposit_window.destroy()

        def validate_amount(new_value):
            if new_value == "":
                return True
            try:
                float(new_value)
                return True
            except ValueError:
                messagebox.showerror("Error", "Invalid input. Please enter a valid number.")
                return False

        self.validate_cmd = self.root.register(validate_amount)

        self.label = tk.Label(self.deposit_window, text="Enter deposit amount:", font=("Arial", 10, "bold")).grid(row=0, column=0)
        self.deposit_amount = tk.Entry(self.deposit_window, validate="key", validatecommand=(self.validate_cmd, '%P'))
        self.deposit_amount.grid(columnspan=2, row=1, column=0)
        tk.Button(self.deposit_window, text="Submit", command=self.submit_deposit).grid(row=2, column=0)
        tk.Button(self.deposit_window, text="Back", command=on_child_window_close).grid(row=2, column=1)

    def submit_deposit(self):

        amount = float(self.deposit_amount.get())

        if not all([amount]):
            self.deposit_amount.focus_set()
            messagebox.showerror("Deposit Failed", "All fields must be filled.")
            return

        try:

            print(amount)
            self.account.deposit_amount(amount)
            self.update_balance_label()

            messagebox.showinfo("Deposit Success", f"Deposit successful! You have deposited: R{amount:.2f}")
            self.clear_deposit()
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def clear_deposit(self):
        self.deposit_amount.delete(0, tk.END)
        self.deposit_amount.focus_set()

    def update_balance_label(self):
        balance = float(self.account.get_balance())
        self.amount.config(text=f"R{balance:.2f}")

    def withdrawal_GUI(self):

        self.withdrawal_window = tk.Toplevel(self.dashboard_window)  # Create a child window
        self.withdrawal_window.title("Withdrawal Window")
        self.dashboard_window.withdraw()

        def on_child_window_close():
            self.dashboard_window.deiconify()
            self.withdrawal_window.destroy()

        self.withdrawal_window.protocol("WM_DELETE_WINDOW", on_child_window_close)

        ttk.Label(self.withdrawal_window, text="Withdrawal", font=("Arial", 10, "bold")).grid(row=0, column=0)
        ttk.Label(self.withdrawal_window, text='Enter withdrawal amount:').grid(row=1, column=0)
        self.withdrawn_amount_entry = tk.Entry(self.withdrawal_window, width=10)
        self.withdrawn_amount_entry.grid(row=1, column=1)

        ttk.Button(self.withdrawal_window, text="Back", command=on_child_window_close).grid(row=2, column=1)
        ttk.Button(self.withdrawal_window, text="Submit", command=self.withdraw_amount).grid(row=2, column=0)

    def withdraw_amount(self):
        amount = float(self.withdrawn_amount_entry.get())

        if not all([amount]):
            self.withdrawn_amount_entry.focus_set()
            messagebox.showerror("Withdrawal Failed", "All fields must be filled.")
            return

        try:

            self.account.withdrawal_amount(amount)
            self.update_balance_label()
            messagebox.showinfo("Withdrawal Success", f"Withdrawal successful! You have withdrawn: R{amount:.2f}")
            self.clear_withdrawal()
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def clear_withdrawal(self):
        self.withdrawn_amount_entry.delete(0, tk.END)
        self.withdrawn_amount_entry.focus_set()

    def airtime_GUI(self):

        self.airtime_window = tk.Toplevel(self.dashboard_window)
        self.airtime_window.title("Airtime Window")
        self.dashboard_window.withdraw()

        def on_child_window_close():
            self.dashboard_window.deiconify()
            self.airtime_window.destroy()

        self.airtime_window.protocol("WM_DELETE_WINDOW", on_child_window_close)


        tk.Label(self.airtime_window, text="Purchase Airtime", font=("Arial", 10, "bold")).grid(row=0, column=0, padx=10, pady=10)
        tk.Label(self.airtime_window, text="Phone Number:").grid(row=1, column=0, padx=10, pady=10)
        tk.Label(self.airtime_window, text="Amount:").grid(row=2, column=0, padx=10, pady=10)

        self.phone_entry = tk.Entry(self.airtime_window, width=30)
        self.phone_entry.grid(row=1, column=1, padx=10, pady=10)

        self.airtime_amount_entry = tk.Entry(self.airtime_window, width=30)
        self.airtime_amount_entry.grid(row=2, column=1, padx=10, pady=10)
        tk.Button(self.airtime_window, text="Recharge", command=self.purchase_airtime).grid(row=3, column=0, columnspan=2)
        tk.Button(self.airtime_window, text="Back", command=on_child_window_close).grid(columnspan=2, row=3, column=1)

    def purchase_airtime(self):
        phone_number = self.phone_entry.get()
        amount = float(self.airtime_amount_entry.get())

        if not all([amount, phone_number]):
            self.phone_entry.focus_set()
            messagebox.showerror("Withdrawal Failed", "All fields must be filled.")
            return

        if not phone_number.isdigit() or len(phone_number) != 10:
            messagebox.showerror("Error", "Please enter a valid 10-digit phone number.")
            return

        if self.account.purchase_airtime_amount(phone_number, amount):
            messagebox.showinfo("Airtime Purchase Successful",
                                f"Airtime of R {amount} has been purchased for {phone_number}.")

        else:
            messagebox.showerror("Insufficient Funds", "You do not have enough balance to purchase this airtime.")

    def clear_airtime(self):
        self.phone_entry.delete(0, tk.END)
        self.airtime_amount_entry.delete(0, tk.END)
        self.phone_entry.focus_set()

    def electricity_GUI(self):
        self.electricity_window = tk.Toplevel(self.dashboard_window)
        self.electricity_window.title("Electricity Window")
        self.dashboard_window.withdraw()

        def on_child_window_close():
            self.dashboard_window.deiconify()  # Show the parent window again
            self.electricity_window.destroy()

        self.electricity_window.protocol("WM_DELETE_WINDOW", on_child_window_close)

        tk.Label(self.electricity_window, text="Purchase Electricity", font=("Arial", 10, "bold")).grid(row=0, column=0)
        tk.Label(self.electricity_window, text="Meter Number:").grid(row=1, column=0)
        tk.Label(self.electricity_window, text="Amount:").grid(row=2, column=0)

        # Create entry widgets
        self.meter_entry = tk.Entry(self.electricity_window, width=30)
        self.meter_entry.grid(row=1, column=1, padx=10, pady=10)

        self.amount_entry = tk.Entry(self.electricity_window, width=30)
        self.amount_entry.grid(row=2, column=1, padx=10, pady=10)

        tk.Button(self.electricity_window, text="Purchase", command=self.purchase_electricity).grid(row=3, column=0)
        tk.Button(self.electricity_window, text="Clear", command="clear ").grid(row=3, column=1)
        tk.Button(self.electricity_window, text="Back", command=on_child_window_close).grid(row=3, column=2)

    def purchase_electricity(self):

        meter_number = self.meter_entry.get()
        amount = self.amount_entry.get()

        if not all([amount, meter_number]):
            self.meter_entry.focus_set()
            messagebox.showerror("Withdrawal Failed", "All fields must be filled.")
            return

        if not meter_number.isdigit() or len(meter_number) != 10:
            messagebox.showerror("Error", "Please enter a valid 10-digit meter number.")
            return

        if self.account.purchase_electricity_amount(meter_number, amount):
            messagebox.showinfo("Airtime Purchase Successful",
                                f"Electricity of R {amount} has been purchased for {meter_number}.")
            self.clear_airtime()

        else:
            messagebox.showerror("Insufficient Funds", "You do not have enough balance to purchase this airtime.")

    def clear_airtime(self):
        self.meter_entry.delete(0, tk.END)
        self.amount_entry.delete(0, tk.END)
        self.meter_entry.focus_set()
    def transaction_GUI(self):
        self.transact_window = tk.Toplevel(self.dashboard_window)
        self.transact_window.title("Bank Statement")
        self.dashboard_window.withdraw()

        def on_child_window_close():
            self.dashboard_window.deiconify()
            self.transact_window.destroy()

        self.transact_window.protocol("WM_DELETE_WINDOW", on_child_window_close)

        tk.Label(self.transact_window, text="Bank Statement", font=headerFont, pady=8).grid(row=0, column=0, columnspan=4)

        self.table = ttk.Treeview(self.transact_window, columns=(
            "Trans Date", "Trans Time", "Trans Type", "Description", "Amount", "Balance"), show='headings', height=8)
        self.table.grid(row=1, column=0, columnspan=4)

        self.table.column("#1", anchor="center", width=100)
        self.table.heading("#1", text="Trans Date")
        self.table.column("#2", anchor="center", width=100)
        self.table.heading("#2", text="Trans Time")
        self.table.column("#3", anchor="center", width=100)
        self.table.heading("#3", text="Trans Type")
        self.table.column("#4", anchor="center", width=200)
        self.table.heading("#4", text="Description")
        self.table.column("#5", anchor="center", width=100)
        self.table.heading("#5", text="Amount")
        self.table.column("#6", anchor="center", width=100)
        self.table.heading("#6", text="Balance")

        self.scrollbar = tk.Scrollbar(self.transact_window, orient="vertical", command=self.table.yview)
        self.scrollbar.grid(row=1, column=5, sticky="ns")
        self.table.configure(yscrollcommand=self.scrollbar.set)


        transactions = []
        with open(transaction_log, 'r') as f:
            transactions = f.readlines()

        for transaction in transactions:
            username, transaction_date, transaction_time, transaction_type, description, amount, balance = transaction.strip().split(',')
            if username == self.account.get_username():
                self.table.insert("", "end", values=(transaction_date, transaction_time, transaction_type, description, amount, balance))

        tk.Button(self.transact_window, text="Email", command="self.email_function", pady=5).grid(row=2, column=0)
        tk.Button(self.transact_window, text="Back", pady=5, command=on_child_window_close).grid(row=2, column=2)


    def transfer_GUI(self):
        self.transfer_window = tk.Toplevel(self.dashboard_window)  # Create a child window
        self.transfer_window.title("Transfer Window")
        self.dashboard_window.withdraw()

        def on_child_window_close():
            self.dashboard_window.deiconify()  # Show the parent window again
            self.transfer_window.destroy()

        self.transfer_window.protocol("WM_DELETE_WINDOW", on_child_window_close)

        tk.Label(self.transfer_window, text='Transaction').grid(row=0, column=0)
        ttk.Label(self.transfer_window, text="Pay Beneficiary", font=("Ariel", 10, "bold")).grid(row=0, column=0)
        tk.Button(self.transfer_window, text="Add Account", command=self.beneficiary_GUI).grid(row=1, column=0)
        tk.Button(self.transfer_window, text="Back", command=on_child_window_close).grid(row=1, column=1)

        self.listbox = tk.Listbox(self.transfer_window)
        self.listbox.insert(1, "Lindiwe Somana")
        self.listbox.insert(2, "Thokozile Vilakazi")
        self.listbox.insert(3, "Sibusiso Somana")
        self.listbox.grid(row=3, column=0, columnspan=2)

    def beneficiary_GUI(self):

        self.beneficiary_window = tk.Toplevel(self.transfer_window)  # Create a child window
        self.beneficiary_window.title("Transfer Window")
        self.transfer_window.withdraw()

        def add_beneficiary():
            beneficiary_name = self.ben_name_entry.get()
            beneficiary_account = self.account_entry.get()
            beneficiary_bank = self.bank_entry.get()
            beneficiary_amount = self.amount_entry.get()

            if not re.match(r'^\d{12}$', beneficiary_account):
                tk.messagebox.showerror("Error", "Account number must be 12 digits long.")
                return

            print(
                f"Beneficiary Name: {beneficiary_name}, Account: {beneficiary_account}, Bank: {beneficiary_bank}, Amount: {beneficiary_amount} added.")

        def on_child_window_close():
            self.transfer_window.deiconify()
            self.beneficiary_window.destroy()

        self.transfer_window.protocol("WM_DELETE_WINDOW", on_child_window_close)

        tk.Label(self.beneficiary_window, text="Beneficiary Name:").grid(row=0, column=0)
        self.ben_name_entry = ttk.Entry(self.beneficiary_window, width=30)
        self.ben_name_entry.grid(row=0, column=1)

        account_label = ttk.Label(self.beneficiary_window, text="Account Number:")
        account_label.grid(row=1, column=0, padx=10, pady=10, sticky="e")
        self.account_number_entry = ttk.Entry(self.beneficiary_window, width=30)
        self.account_number_entry.grid(row=1, column=1)

        tk.Label(self.beneficiary_window, text="Bank Name:").grid(row=2, column=0, padx=10, pady=10, sticky="e")
        self.bank_name_entry = ttk.Entry(self.beneficiary_window, width=30)
        self.bank_name_entry.grid(row=2, column=1, padx=10, pady=10)

        tk.Label(self.beneficiary_window, text="Amount:").grid(row=3, column=0, padx=10, pady=10, sticky="e")
        self.trans_amount_entry = ttk.Entry(self.beneficiary_window, width=30)
        self.trans_amount_entry.grid(row=3, column=1, padx=10, pady=10)

        tk.Button(self.beneficiary_window, text="Add Beneficiary", command=self.transfer_amount).grid(row=4, column=0)
        tk.Button(self.beneficiary_window, text="Clear", command=self.clear_transfer).grid(row=4, column=1)
        tk.Button(self.beneficiary_window, text="Back", command=on_child_window_close).grid(row=4, column=2)

    def transfer_amount(self):

        amount = float(self.trans_amount_entry.get())
        name = self.ben_name_entry.get()
        beneficiary_bank = self.bank_name_entry.get()
        acc_num = self.account_number_entry.get()

        if not all([amount, beneficiary_bank, acc_num,name]):
            self.ben_name_entry.focus_set()
            messagebox.showerror("Withdrawal Failed", "All fields must be filled.")
            return

        if not re.match(r'^\d{12}$', acc_num):
            tk.messagebox.showerror("Error", "Account number must be 12 digits long.")
            return

        try:

            self.account.transferred_amount(name, amount)
            self.update_balance_label()
            messagebox.showinfo("Transfer Success", f"Transfer was successful! You have transferred: R{amount:.2f} to {name}")
            self.clear_transfer()
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def clear_transfer(self):
        self.ben_name_entry.delete(0, tk.END)
        self.bank_name_entry.delete(0, tk.END)
        self.trans_amount_entry.delete(0, tk.END)
        self.account_number_entry.delete(0, tk.END)

        self.ben_name_entry.focus_set()

    def profile_GUI(self, username):
        self.profile_window = tk.Toplevel(self.dashboard_window)
        self.profile_window.title("View Profile Details")
        self.dashboard_window.withdraw()

        def on_child_window_close():
            self.dashboard_window.deiconify()  # Show the parent window again
            self.profile_window.destroy()

        self.profile_window.protocol("WM_DELETE_WINDOW", on_child_window_close)

        amount = float(self.account.get_balance())
        name = str(self.users[username]['name'])
        surname = str(self.users[username]['surname'])
        fullname = name + " " + surname
        acc = str(self.users[username]['account_num'])
        tk.Label(self.profile_window, text="Profile Details", font=headerFont).grid(row=0, column=0)
        tk.Label(self.profile_window, text="Full Name: ", pady=5).grid(row=1, column=0)
        tk.Label(self.profile_window, text="Gender: ", pady=5).grid(row=2, column=0)
        tk.Label(self.profile_window, text="Email: ", pady=5).grid(row=3, column=0)
        tk.Label(self.profile_window, text="Contact Number: ", pady=5).grid(row=4, column=0)
        tk.Label(self.profile_window, text="Username", pady=5).grid(row=5, column=0)
        tk.Label(self.profile_window, text="Password", pady=5).grid(row=6, column=0)
        tk.Label(self.profile_window, text="Account Number:", pady=5).grid(row=7, column=0)
        tk.Label(self.profile_window, text="Balance:", pady=5).grid(row=8, column=0)

        tk.Label(self.profile_window, text=fullname, pady=5).grid(row=1, column=1)
        tk.Label(self.profile_window, text=str(self.users[username]['gender']), pady=5).grid(row=2, column=1)
        tk.Label(self.profile_window, text=str(self.users[username]['email']), pady=5).grid(row=3, column=1)
        tk.Label(self.profile_window, text=str(self.users[username]['contact']), pady=5).grid(row=4, column=1)
        tk.Label(self.profile_window, text=str(self.users[username]['username']), pady=5).grid(row=5, column=1)
        tk.Label(self.profile_window, text=str(self.users[username]['password']), pady=5).grid(row=6, column=1)
        tk.Label(self.profile_window, text=acc, pady=5).grid(row=7, column=1)
        tk.Label(self.profile_window, text=f"R{amount:.2f}", pady=5).grid(row=8, column=1)

        tk.Button(self.profile_window, text="Close", command=on_child_window_close, width=30).grid(columnspan=2, row=9, column=0)

    def login(self):
        username = self.username_login.get()
        password = self.password_login.get()

        if username == "" or password == "":
            self.username_login.focus_set()
            print("here")
            return

        if username in self.users:
            if self.users[username]["password"] == password:
                messagebox.showinfo("Login Success", f"Welcome, {self.users[username]['name']}!")

                self.login_window.withdraw()
                self.set_account_info(username)
                self.dashboard_GUI(username)


            else:
                messagebox.showerror("Error", "Incorrect password. Please try again.")
        else:
            messagebox.showerror("Error", "Username does not exist. Please try again or sign up.")

    def send_email(self, username):
        subject = "Young Division Bank Account Confirmation"
        header = "<h1 style='text-align: center;'>Signup Successful</h1>"
        body = f"""
                {header}
                <p>Dear {self.users[username]['name']} {self.users[username]['surname']},</p>
                <p>
                    We are pleased to inform you that your account has been successfully created. Below are your account details:
                </p>
                <ul>
                    <li><b>First Name:</b> {self.users[username]['name']}</li>
                    <li><b>Last Name:</b> {self.users[username]['surname']}</li>
                    <li><b>Gender:</b> {self.users[username]['gender']}</li>
                    <li><b>Email:</b> {self.users[username]['email']}</li>
                    <li><b>Contact Number:</b> {self.users[username]['contact']}</li>
                    <li><b>Username:</b> {self.users[username]['username']}</li>
                    <li><b>Password:</b> {self.users[username]['password']}</li>
                    <li><b>Account Number:</b> {self.users[username]['account_num']}</li>
                    <li><b>Balance:</b> R  {self.users[username]['balance']}</li>

                </ul>

                <p>If you would like to change your password, or need any addition help please contact the support team.</p>
                <p>Sincerely,<br>Young Devs Supports</p>
                """

        company_email = 'youngdivisionbank@gmail.com'
        company_password = 'kfwcqcdtwrcfbedn'

        user_email = str(self.users[username]['email'])
        print(user_email)

        message = MIMEMultipart()
        message['From'] = company_email
        message['To'] = user_email
        message['Subject'] = subject

        message.attach(MIMEText(body, 'html'))

        try:
            with smtplib.SMTP('smtp.gmail.com', 587) as server:
                server.starttls()
                server.login(company_email, company_password)
                text = message.as_string()
                server.sendmail(company_email, user_email, text)
                server.quit()
                messagebox.showinfo("Success", "Email sent successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to send email. Error message: {str(e)}")

    def set_account_info(self, username):
        user_info = self.users.get(username)
        if user_info:
            self.account = BankAccount(
                username=username,
                password=user_info.get("password"),
                first_name=user_info.get("firstname"),
                last_name=user_info.get("lastname"),
                gender=user_info.get("gender"),
                email=user_info.get("email"),
                contact_num=user_info.get("contact_number")
            )
            self.account.account_number = user_info.get("account_num")
            self.account.balance = user_info.get("balance")
            print(self.account.__str__())
        else:
            messagebox.showerror("Error", "Failed to retrieve account information.")


    def signup(self):

        self.gpassword_entry.config(state='normal')

        name = self.first_name_entry.get()
        surname = self.last_name_entry.get()
        gender = self.selected_value.get()
        num = self.contact_entry.get()
        email = self.email_entry.get()
        username = self.username_entry.get()
        password_gen = self.gpassword_entry.get()

        def check_email(email):
            if re.match(r"[^@]+@[^@]+\.[^@]+", email):
                return True
            return False

        if not all([name, surname, num, email, username]):
            self.first_name_entry.focus_set()
            messagebox.showerror("Signup Failed", "All fields must be filled.")
            return

        if name.isalpha() and surname.isalpha() and check_email(email) and num.isnumeric() and username.isalpha():
            print("successful")
        else:
            messagebox.showerror("Signup Failed", "Invalid input. Please check your details.")
            return

        user_info = {
            "username": username,
            "password": password_gen,
            "name": name,
            "surname": surname,
            "gender": gender,
            "email": email,
            "contact": num,
        }

        if user_info["username"] in self.users:
            messagebox.showerror("Signup Failed", "Username already exists.")
            return
        else:
            self.users[user_info["username"]] = user_info
            self.bank_account = BankAccount(username, password_gen, name, surname, gender, email, num)
            print("username")
            self.bank_account.save_account_info()
            print("not working")
            messagebox.showinfo("Signup Success", "You have successfully signed up.")
            self.signup_window.withdraw()
            self.login_GUI()

    def close_application(self):
        if messagebox.askokcancel("Quit", "Do you really want to quit?"):
            self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = BankingAppGUI(root)
    root.mainloop()
