import random
import string

from datetime import datetime

accounts = "BankAccountData.txt"
transaction_log_file = "transaction_log.txt"


class BankAccount:

    def __init__(self, username, password, first_name, last_name, gender, email, contact_num):
        self.username = username
        self.password = password
        self.firstname = first_name
        self.lastname = last_name
        self.gender = gender
        self.email = email
        self.contact_number = contact_num
        self.account_number = self.generate_account_number()
        self.balance = float(0.00)

    def generate_account_number(self):
        return ''.join(random.choices(string.digits, k=10))

    def set_account_attributes(self, user_info):
        self.username = user_info.get('username')
        self.password = user_info.get('password')
        self.firstname = user_info.get('name')
        self.lastname = user_info.get('surname')
        self.gender = user_info.get('gender')
        self.email = user_info.get('email')
        self.contact_number = user_info.get('contact')
        self.account_number = user_info.get('account_num')
        self.balance = float(user_info.get('balance'))

    def get_firstname(self):
        return self.firstname

    def get_lastname(self):
        return self.lastname

    def get_fullname(self):
        return " ".join([str(self.firstname), str(self.lastname)])

    def get_gender(self):
        return self.gender

    def get_email(self):
        return self.email

    def get_contact_num(self):
        return self.contact_number

    def get_balance(self):
        return self.balance

    def get_acc_number(self):
        return self.account_number

    def get_username(self):
        return self.username

    def get_password(self):
        return self.password

    def save_account_info(self):
        with open(accounts, "a") as file:
            file.write(
                f"{self.username},{self.password},{self.firstname},{self.lastname},{self.gender},"
                f"{self.email},{self.contact_number},{self.account_number},{self.balance}\n")

    def deposit_amount(self, amount):
        amount = float(amount)

        if amount <= 0:
            raise ValueError("Deposit amount must be positive.")
        deposit = float(self.balance) + amount
        self.balance = str(deposit)
        self.update_user_balance()
        self.record_transaction("Deposit", "Personal Deposit",  "+ R " + str(amount))

        return self.balance

    def withdrawal_amount(self, amount):

        amount = float(amount)
        if amount <= 0:
            raise ValueError("Withdrawal amount must be positive.")

        if amount <= float(self.balance):
            withdraw = float(self.balance) - amount
            self.balance = str(withdraw)
            self.update_user_balance()
            self.record_transaction("Withdrawal", "Personal Withdrawal", "- R " + str(amount))
            return self.balance
        else:
            raise ValueError("Insufficient funds.")

    def purchase_airtime_amount(self, phone_number, amount):

        amount = float(amount)
        if amount <= 0:
            raise ValueError("Airtime amount must be positive.")

        if amount <= float(self.balance):
            withdraw = float(self.balance) - amount
            self.balance = str(withdraw)
            self.update_user_balance()
            self.record_transaction("Airtime", "Airtime Number: " + phone_number, "- R " + str(amount))
            return self.balance
        else:
            raise ValueError("Insufficient funds.")

    def purchase_electricity_amount(self, meter_num, amount):

        amount = float(amount)
        if amount <= 0:
            raise ValueError("Electricity amount must be positive.")

        if amount <= float(self.balance):
            withdraw = float(self.balance) - amount
            self.balance = str(withdraw)
            self.update_user_balance()
            self.record_transaction("Electricity", "Meter Number: " + meter_num, "- R " + str(amount))
            return self.balance
        else:
            raise ValueError("Insufficient funds.")

    def transferred_amount(self, name, amount):

        amount = float(amount)
        if amount <= 0:
            raise ValueError("Transfer amount must be positive.")

        if amount <= float(self.balance):
            transfer = float(self.balance) - amount
            self.balance = str(transfer)
            self.update_user_balance()
            self.record_transaction("Transfer", "Payment to: " + name, "- R " + str(amount))
            return self.balance
        else:
            raise ValueError("Insufficient funds.")

    def record_transaction(self, transaction_type, description, balance):
        now = datetime.now()
        date = now.strftime("%Y/%m/%d")
        time = now.strftime("%H:%M")

        amount_after ="R " + str(self.balance)
        with open(transaction_log_file, 'a') as f:
            f.write(f"{self.username},{date},{time},{transaction_type},{description},{balance},{amount_after}\n")


    def update_user_balance(self):
        # Read all lines from the file
        with open(accounts, 'r') as file:
            lines = file.readlines()

        # Open the file in write mode to update the content
        with open(accounts, 'w') as file:
            for line in lines:
                # Split each line by comma to extract user details
                user_data = line.strip().split(',')
                if user_data[0] == self.username:
                    # Update the balance
                    user_data[8] = str(self.balance)
                    # Reconstruct the line
                    line = ','.join(user_data) + '\n'
                # Write the line back to the file
                file.write(line)


    def __str__(self):
        return f"Account Details: {self.username}, {self.firstname} {self.lastname}, Balance: {self.balance}"

    #def record_transaction(username, transaction_type, amount):
    #   with open(transaction_log_file, 'a') as f:
    #       f.write(f"{username},{transaction_type},{amount},{datetime.datetime.now()}\n")
    #toString
    def __str__(self):
        return f"{self.username},{self.password},{self.firstname},{self.lastname},{self.gender},{self.email},{self.contact_number},{self.account_number},{self.balance}"
